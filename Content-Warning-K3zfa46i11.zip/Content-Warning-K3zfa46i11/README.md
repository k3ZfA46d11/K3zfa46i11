# 如何使用
> 你必须安装BepinEx模组才能使用此作弊模组

- 下载[Release](https://github.com/xiaodo1337/Content-Warning-Cheat/releases/tag/v1)内的plugins.zip压缩包
- 将压缩包内plugins文件夹放到游戏根目录里的BepinEx文件夹内
- 启动游戏，按下Insert键在游戏内呼出菜单！

# 截图
![截图1](https://raw.githubusercontent.com/xiaodo1337/Content-Warning-Cheat/master/1.png)
![截图2](https://raw.githubusercontent.com/xiaodo1337/Content-Warning-Cheat/master/2.png)
![截图3](https://raw.githubusercontent.com/xiaodo1337/Content-Warning-Cheat/master/3.png)
![截图4](https://raw.githubusercontent.com/xiaodo1337/Content-Warning-Cheat/master/4.png)
![截图5](https://raw.githubusercontent.com/xiaodo1337/Content-Warning-Cheat/master/5.png)
